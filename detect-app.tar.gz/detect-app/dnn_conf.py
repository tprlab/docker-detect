DNN_PATH = "/ssd_mobilenet_v1_coco_11_06_2017/frozen_inference_graph.pb"
DNN_TXT_PATH = "/detect/opencv-extra/ssd_mobilenet_v1_coco.pbtxt"
DNN_LABELS_PATH = "/detect/opencv-extra/mscoco_label_map.pbtxt"

LOG_PATH = "/detect/logs"
LOG_FILE = "dnn_rest.log"

